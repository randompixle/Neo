
__version__ = "0.5.0"
__codename__ = "Solar"
__product__ = "Solar Neo"
