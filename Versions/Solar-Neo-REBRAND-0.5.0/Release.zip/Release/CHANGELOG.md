
# Solar Neo — Changelog

## v0.5.0 — Project: SOLAR
- Renamed CLI to `solar`
- New diagnostics command: `solar sys`
- Purple theme output polish
- rpm-ostree read-only detection + Flatpak fallback
- Self-update via GitHub Releases (with fallback to source ZIP)
- Clean uninstall (`solar uninstall-self`)
