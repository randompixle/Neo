__version__ = "v0.6"
__codename__ = "Solar"
__product__ = "Solar Neo"
