import sys
from .utils.run import main

if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
